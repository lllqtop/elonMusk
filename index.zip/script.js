var header = document.querySelector('header');

window.addEventListener('scroll', function() {
    var scrolled = window.scrollY;

    // Вычисляем значение альфа-канала в зависимости от прокрутки
    var alpha = Math.min(scrolled / 200, 0.6); // 200 - высота, на которой будет максимальная матовость

    // Применяем изменения к цвету фона
    header.style.backgroundColor = 'rgba(211, 211, 211, ' + (0.9 - alpha) + ')';
});

